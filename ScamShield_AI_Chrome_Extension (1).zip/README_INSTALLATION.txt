ScamShield AI Chrome Extension

INSTALLATION (Google Chrome)
1. Extract this ZIP file into a folder.
2. Open Chrome and visit chrome://extensions
3. Turn on Developer mode.
4. Click Load unpacked.
5. Select the extracted folder containing manifest.json.
6. Pin ScamShield AI from the Extensions menu if you want quick access.

USAGE
- Paste a job description and click Analyze Job Description, or
- Open a job listing and click Analyze Current Page.
- An internet connection is required. The extension sends the job description to the ScamShield AI service at https://scamshield-ai-0aa0.onrender.com/api/analyze for analysis.

PRIVACY AND LIMITATIONS
Only submit text you are comfortable sending to the online analysis service. The extension provides an estimated risk assessment, not proof that a job is genuine or fraudulent. Verify employers independently.

This is an unpacked extension package for manual installation; it is not a Chrome Web Store listing.
